#!/usr/bin/env sh

./scripts/list-sources.sh > sources.mk
