/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lduplain <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/26 18:39:35 by lduplain          #+#    #+#             */
/*   Updated: 2020/09/27 19:57:18 by dburgun          ###   ########lyon.fr   */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

int		main(int argc, char **argv)
{
	char	**dictionnary;
	char	*dictionnary_path;
	char	*number;
	char 	**parts;
	int		part_count;

	if (argc == 1 || argc > 3)
		if (print_error(0))
			return (0);
	if (argc == 3)
	{
		dictionnary_path = argv[1];
		number = argv[2];
	}
	if (argc == 2)
	{
		dictionnary_path = "numbers.dict";
		number = argv[1];
	}
	if (!valid_args(dictionnary_path, number))
		return (0);
	dictionnary = generate_table(dictionnary_path);
	complete_dictionnary(dictionnary, dictionnary_path);
	format_dictionnary(dictionnary);
	parts = truncate_number(number, &part_count);
	// int i = 0;
	// while (i < part_count)
	// {
	// 	printf("part %d :", i);
	// 	printf("%c", parts[i][0]);
	// 	printf("%c", parts[i][1]);
	// 	printf("%c\n", parts[i][2]);
	// 	i++;
	// }
	if (ft_strcmp(number, "0") == 0)
		ft_putstr(get_value_by_key(dictionnary, "0"));
	else
		print_number(parts, part_count, dictionnary);
	free(parts);
}
