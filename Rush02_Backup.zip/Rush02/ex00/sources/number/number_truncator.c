/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   number_truncator.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lduplain <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/27 15:50:11 by lduplain          #+#    #+#             */
/*   Updated: 2020/09/27 19:41:13 by dburgun          ###   ########lyon.fr   */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

void	complete_by(char *str, char c)
{
	int i;

	i = -1;
	while (++i < 3)
		str[i] = c;
}

char	**truncate_number(char *number, int *table_size)
{
	int		i;
	int		j;
	char	*block;
	char	**result;
	int		number_len;
	
	number_len = ft_strlen(number);
	*table_size = (number_len / 3) + (number_len % 3 ? 1 : 0);
	result = malloc(*table_size * sizeof(char*));
	if (!result)
		return (NULL);
	i = 0;
	while (number_len >= 3)
	{
		block = &number[number_len - 3];
		result[i] = malloc(3 * sizeof(char));
		j = 0;
		while (j < 3)
		{
			result[i][j] = block[j];
			j++;
		}
		number_len -= 3;
		i++;
	}
	if (number_len)
	{
		result[i] = malloc(3 * sizeof(char));
		j = 0;
		while (j < 3 - number_len)
		{
			result[i][j] = '0';
			j++;
		}
		while (j < 3)
		{
			result[i][j] = number[j + number_len - 3];
			j++;
		}
	}
	return (result);
}
