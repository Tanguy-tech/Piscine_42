/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_number.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dburgun <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/27 18:49:06 by dburgun           #+#    #+#             */
/*   Updated: 2020/09/27 20:46:10 by dburgun          ###   ########lyon.fr   */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

void	print_part(char part[3], char **dictionnary)
{
	char	*name;
	char	str[3];

	if (part[0] != '0')
	{
		str[1] = '\0';
		str[0] = part[0];
		ft_putstr(get_value_by_key(dictionnary, str));
		ft_putstr(" ");
		ft_putstr(get_value_by_key(dictionnary, "100"));
	}

	if (part[1] != '0')
	{
		if (part[0] != '0')
			ft_putstr(" ");
		str[0] = part[1];
		str[1] = part[2];
		str[2] = '\0';

		name = get_value_by_key(dictionnary, str);
		if (name)
		{
			ft_putstr(name);
			free(name);
			return ;
		}

		str[1] = '0';
		name = get_value_by_key(dictionnary, str);
		if (name)
		{
			ft_putstr(name);
			free(name);
		}
		else
		{
			str[1] = '\0';
			str[0] = part[1];
			ft_putstr(get_value_by_key(dictionnary, str));
			ft_putstr(" ");
			ft_putstr(get_value_by_key(dictionnary, "10"));
		}
	}
	if (part[2] != '0')
	{
		if (part[0] != '0' || part[1] != '0')
			ft_putstr(" ");
		str[1] = '\0';
		str[0] = part[2];
		ft_putstr(get_value_by_key(dictionnary, str));
	}
}

void	print_suffix(int index, char **dictionnary)
{
	int		i;
	char	*name;
	char	*to_search;
	
	to_search = malloc(3 * index  + 2);
	to_search[0] = '1';
	i = 1;
	while (i < 3 * index + 1)
	{
		to_search[i] = '0';
		i++;
	}
	to_search[i] = '\0';
	name = get_value_by_key(dictionnary, to_search);
	ft_putstr(name);
	free(name);
	free(to_search);
}

void	print_number(char **parts, int part_count, char **dictionnary)
{
	int		i;
	int		b;

	i = part_count;
	b = 0;
	while (--i)
	{
		if ( !(parts[i][0] == '0' && parts[i][1] == '0' && parts[i][2] == '0'))
		{
			if (b)
			{
				ft_putstr(" ");
				b = 0;
			}
			print_part(parts[i], dictionnary);
			ft_putstr(" ");
			print_suffix(i, dictionnary);
			b = 1;
		}
	}
	print_part(parts[i], dictionnary);
}
